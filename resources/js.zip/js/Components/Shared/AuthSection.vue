<template #content>

    <li class="menu-item" v-if="!$page.props.user"><Link title="Login" :href="route('login')">Login</Link></li>
    <li class="menu-item" v-if="!$page.props.user"><Link title="Register" :href="route('register')">Register</Link></li>
    <!-- Account Management -->
    <li class="menu-item" v-if="$page.props.user">
        <div class="flex-shrink-0 dropdown">
            <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle" id="dropdownAuth" data-bs-toggle="dropdown" aria-expanded="false">
                Manage Account ({{ $page.props.user.name }})
            </a>
            <ul class="dropdown-menu text-small shadow" aria-labelledby="dropdownAuth" style="">
                <li><a class="dropdown-item" href="#">New project...</a></li>
                <li><a class="dropdown-item" href="#">Settings</a></li>
                <li><a class="dropdown-item" href="#">Profile</a></li>
                <li><hr class="dropdown-divider"></li>
                <li v-if="this.$page.props.user.role == 'admin'"><Link class="dropdown-item" href="/admin/dashboard">Dashboard</Link></li>
                <li v-if="this.$page.props.user.role == 'admin'"><Link class="dropdown-item" href="/admin/categories">Categories</Link></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="#">
                    <!-- Authentication -->
                    <form @submit.prevent="logout">
                        <button type="submit" class="btn btn-link p-0 text-dark text-decoration-none">
                        Logout <span class="fa fa-sign-out"></span></button>
                    </form>
                </a></li>
            </ul>
        </div>
    </li>


</template>

<script>
export default {

    data() {
        return {
            hideDropDown: ''
        }
    },
    methods: {
        logout() {
            // this.$inertia.post(route('logout'));
            this.hideDropDown = 'collapse';
        },
    },
    mounted() {
        // alert('ddd')
        // console.log('ddsds->dddseswewe');
        // console.log($page.props.user)
    }
}
</script>
