<template>
    <div v-if="successMessage" class="alert alert-success">
        {{ successMessage }}
    </div>
    <div v-if="info" class="alert alert-info">
        {{ info }}
    </div>
    <div v-if="light" class="alert alert-light">
        {{ light }}
    </div>
    <div v-if="warning" class="alert alert-warning">
        {{ warning }}
    </div>
    <div v-if="danger" class="alert alert-danger">
        {{ danger }}
    </div>
    <div v-if="Object.keys(validationErrors).length > 0" class="alert alert-danger">
        <ul>
            <li v-for="error in validationErrors">{{ error }}</li>
        </ul>
    </div>
</template>
<script>
export default {
    computed: {
        successMessage(){
            return this.$page.props.successMessage
        },
        info(){
            return this.$page.props.info
        },
        light(){
            return this.$page.props.light
        },
        warning(){
            return this.$page.props.warning
        },
        danger(){
            return this.$page.props.danger
        },

        validationErrors(){
            return this.$page.props.errors
        }
    },
    mounted() {

        // let errors = this.$page.props.errors;
        // let size = Object.keys(errors).length;
        // console.log(size)
        // console.log((this.$page.props.errors).odf);
    }
}
</script>
