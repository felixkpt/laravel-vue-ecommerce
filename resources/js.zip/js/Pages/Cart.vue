<template>
    <Layout>
        <!--main area-->
        <main id="main" class="main-site">

            <div class="container">

                <div class="wrap-breadcrumb">
                    <ul>
                        <li class="item-link"><a href="#" class="link">home</a></li>
                        <li class="item-link"><span>login</span></li>
                    </ul>
                </div>
                <Notification />
                <div class="main-content-area">

                    <div class="wrap-iten-in-cart">
                        <h3 class="box-title">Products Name</h3>
                        <ul class="products-cart">
                            <li class="pr-cart-item" v-for="item in $page.props.cart">
                                <div class="product-image" v-if="item.model">
                                    <figure><img :src="`/assets/images/products/${item.model.image}`" alt=""></figure>
                                </div>
                                <div class="product-name">
                                    <Link class="link-to-product" :href="`/product/${item.model.slug}`">{{ item.name }}</Link>
                                </div>
                                <div class="price-field produtc-price"><p class="price">{{ item.price }}</p></div>
                                <div class="quantity">
                                    <div class="quantity-input py-2">

                                        <input type="text" :id="`id_${item.rowId}`" :value="item.qty" data-max="120" pattern="[0-9]*">

                                        <div @click="decreaseQuantity(`id_${item.rowId}`)"
                                                 class="d-inline p-2 rounded-circle text-center m-0 mx-1 bg-light"
                                                 style="min-width: 30px!important;height: 30px;padding: 3px 3px">
                                                <span class="fa fa-minus"></span>
                                            </div>
                                        <div @click="increaseQuantity(`id_${item.rowId}`)"
                                             class="d-inline p-2 rounded-circle text-center m-0 mx-1 bg-light"
                                             style="min-width: 30px!important;height: 30px;padding: 2px 8px">
                                            <span class="fa fa-plus"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="price-field sub-total"><p class="price">{{ item.price }}</p></div>
                                <div class="delete">
                                    <button class="btn btn-light btn-sm btn-dark rounded-circle" style="width: 30px; height: 30px" title="" @click="remove(`id_${item.rowId}`)">
<!--                                        <span>Delete from your cart</span>-->
                                        <i class="fa fa-times-circle" style="font-size: large" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </li>

                        </ul>
                    </div>

                    <div class="summary">
                        <div class="order-summary">
                            <h4 class="title-box">Order Summary</h4>
                            <p class="summary-info"><span class="title">Subtotal</span><b class="index">${{ $page.props.subtotal }}</b></p>
                            <p class="summary-info"><span class="title">Tax</span><b class="index">${{ $page.props.tax }}</b></p>
                            <p class="summary-info"><span class="title">Shipping</span><b class="index">Free Shipping</b></p>
                            <p class="summary-info total-info "><span class="title">Total</span><b class="index">${{ $page.props.total }}</b></p>
                        </div>
                        <div class="checkout-info">
                            <label class="checkbox-field">
                                <input class="frm-input " name="have-code" id="have-code" value="" type="checkbox"><span>I have promo code</span>
                            </label>
                            <a class="btn btn-checkout" href="/checkout">Check out</a>
                            <a class="link-to-shop" href="/shop">Continue Shopping<i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a>
                        </div>
                        <div class="update-clear">
                            <button class="btn btn-clear" @click="destroy">Clear Shopping Cart</button>
                            <button class="btn btn-update" @click="update">Update Shopping Cart</button>
                        </div>
                    </div>

                    <div class="wrap-show-advance-info-box style-1 box-in-site">
                        <h3 class="title-box">Most Viewed Products</h3>
                        <div class="wrap-products">
                            <div class="products slide-carousel owl-carousel style-nav-1 equal-container" data-items="5" data-loop="false" data-nav="true" data-dots="false" data-responsive='{"0":{"items":"1"},"480":{"items":"2"},"768":{"items":"3"},"992":{"items":"3"},"1200":{"items":"5"}}' >

                                <div class="product product-style-2 equal-elem ">
                                    <div class="product-thumnail">
                                        <a href="#" title="T-Shirt Raw Hem Organic Boro Constrast Denim">
                                            <figure><img src="/assets/images/products/digital_4.jpg" width="214" height="214" alt="T-Shirt Raw Hem Organic Boro Constrast Denim"></figure>
                                        </a>
                                        <div class="group-flash">
                                            <span class="flash-item new-label">new</span>
                                        </div>
                                        <div class="wrap-btn">
                                            <a href="#" class="function-link">quick view</a>
                                        </div>
                                    </div>
                                    <div class="product-info">
                                        <a href="#" class="product-name"><span>Radiant-360 R6 Wireless Omnidirectional Speaker [White]</span></a>
                                        <div class="wrap-price"><span class="product-price">$250.00</span></div>
                                    </div>
                                </div>

                                <div class="product product-style-2 equal-elem ">
                                    <div class="product-thumnail">
                                        <a href="#" title="T-Shirt Raw Hem Organic Boro Constrast Denim">
                                            <figure><img src="/assets/images/products/digital_17.jpg" width="214" height="214" alt="T-Shirt Raw Hem Organic Boro Constrast Denim"></figure>
                                        </a>
                                        <div class="group-flash">
                                            <span class="flash-item sale-label">sale</span>
                                        </div>
                                        <div class="wrap-btn">
                                            <a href="#" class="function-link">quick view</a>
                                        </div>
                                    </div>
                                    <div class="product-info">
                                        <a href="#" class="product-name"><span>Radiant-360 R6 Wireless Omnidirectional Speaker [White]</span></a>
                                        <div class="wrap-price"><ins><p class="product-price">$168.00</p></ins> <del><p class="product-price">$250.00</p></del></div>
                                    </div>
                                </div>

                                <div class="product product-style-2 equal-elem ">
                                    <div class="product-thumnail">
                                        <a href="#" title="T-Shirt Raw Hem Organic Boro Constrast Denim">
                                            <figure><img src="/assets/images/products/digital_15.jpg" width="214" height="214" alt="T-Shirt Raw Hem Organic Boro Constrast Denim"></figure>
                                        </a>
                                        <div class="group-flash">
                                            <span class="flash-item new-label">new</span>
                                            <span class="flash-item sale-label">sale</span>
                                        </div>
                                        <div class="wrap-btn">
                                            <a href="#" class="function-link">quick view</a>
                                        </div>
                                    </div>
                                    <div class="product-info">
                                        <a href="#" class="product-name"><span>Radiant-360 R6 Wireless Omnidirectional Speaker [White]</span></a>
                                        <div class="wrap-price"><ins><p class="product-price">$168.00</p></ins> <del><p class="product-price">$250.00</p></del></div>
                                    </div>
                                </div>

                                <div class="product product-style-2 equal-elem ">
                                    <div class="product-thumnail">
                                        <a href="#" title="T-Shirt Raw Hem Organic Boro Constrast Denim">
                                            <figure><img src="/assets/images/products/digital_1.jpg" width="214" height="214" alt="T-Shirt Raw Hem Organic Boro Constrast Denim"></figure>
                                        </a>
                                        <div class="group-flash">
                                            <span class="flash-item bestseller-label">Bestseller</span>
                                        </div>
                                        <div class="wrap-btn">
                                            <a href="#" class="function-link">quick view</a>
                                        </div>
                                    </div>
                                    <div class="product-info">
                                        <a href="#" class="product-name"><span>Radiant-360 R6 Wireless Omnidirectional Speaker [White]</span></a>
                                        <div class="wrap-price"><span class="product-price">$250.00</span></div>
                                    </div>
                                </div>

                                <div class="product product-style-2 equal-elem ">
                                    <div class="product-thumnail">
                                        <a href="#" title="T-Shirt Raw Hem Organic Boro Constrast Denim">
                                            <figure><img src="/assets/images/products/digital_21.jpg" width="214" height="214" alt="T-Shirt Raw Hem Organic Boro Constrast Denim"></figure>
                                        </a>
                                        <div class="wrap-btn">
                                            <a href="#" class="function-link">quick view</a>
                                        </div>
                                    </div>
                                    <div class="product-info">
                                        <a href="#" class="product-name"><span>Radiant-360 R6 Wireless Omnidirectional Speaker [White]</span></a>
                                        <div class="wrap-price"><span class="product-price">$250.00</span></div>
                                    </div>
                                </div>

                                <div class="product product-style-2 equal-elem ">
                                    <div class="product-thumnail">
                                        <a href="#" title="T-Shirt Raw Hem Organic Boro Constrast Denim">
                                            <figure><img src="/assets/images/products/digital_3.jpg" width="214" height="214" alt="T-Shirt Raw Hem Organic Boro Constrast Denim"></figure>
                                        </a>
                                        <div class="group-flash">
                                            <span class="flash-item sale-label">sale</span>
                                        </div>
                                        <div class="wrap-btn">
                                            <a href="#" class="function-link">quick view</a>
                                        </div>
                                    </div>
                                    <div class="product-info">
                                        <a href="#" class="product-name"><span>Radiant-360 R6 Wireless Omnidirectional Speaker [White]</span></a>
                                        <div class="wrap-price"><ins><p class="product-price">$168.00</p></ins> <del><p class="product-price">$250.00</p></del></div>
                                    </div>
                                </div>

                                <div class="product product-style-2 equal-elem ">
                                    <div class="product-thumnail">
                                        <a href="#" title="T-Shirt Raw Hem Organic Boro Constrast Denim">
                                            <figure><img src="/assets/images/products/digital_4.jpg" width="214" height="214" alt="T-Shirt Raw Hem Organic Boro Constrast Denim"></figure>
                                        </a>
                                        <div class="group-flash">
                                            <span class="flash-item new-label">new</span>
                                        </div>
                                        <div class="wrap-btn">
                                            <a href="#" class="function-link">quick view</a>
                                        </div>
                                    </div>
                                    <div class="product-info">
                                        <a href="#" class="product-name"><span>Radiant-360 R6 Wireless Omnidirectional Speaker [White]</span></a>
                                        <div class="wrap-price"><span class="product-price">$250.00</span></div>
                                    </div>
                                </div>

                                <div class="product product-style-2 equal-elem ">
                                    <div class="product-thumnail">
                                        <a href="#" title="T-Shirt Raw Hem Organic Boro Constrast Denim">
                                            <figure><img src="/assets/images/products/digital_5.jpg" width="214" height="214" alt="T-Shirt Raw Hem Organic Boro Constrast Denim"></figure>
                                        </a>
                                        <div class="group-flash">
                                            <span class="flash-item bestseller-label">Bestseller</span>
                                        </div>
                                        <div class="wrap-btn">
                                            <a href="#" class="function-link">quick view</a>
                                        </div>
                                    </div>
                                    <div class="product-info">
                                        <a href="#" class="product-name"><span>Radiant-360 R6 Wireless Omnidirectional Speaker [White]</span></a>
                                        <div class="wrap-price"><span class="product-price">$250.00</span></div>
                                    </div>
                                </div>
                            </div>
                        </div><!--End wrap-products-->
                    </div>

                </div><!--end main content area-->
            </div><!--end container-->

        </main>
        <!--main area-->
    </Layout>
</template>
<script>
import Layout from '@/Components/Shared/Layout';
import Notification from '@/Components/Shared/Notification';
export default  {
    components: {
        Layout,
        Notification,
    },
    data() {
        return {
        qty: 23,
        }
    },
    methods: {
        increaseQuantity(rowId) {
            this.action(rowId, 'increase');

        },
        decreaseQuantity(rowId) {
            this.action(rowId, 'decrease');
        },
        remove(rowId) {
            this.$inertia.post('/cart/remove', {rowId: rowId});
        },
        destroy() {
            this.$inertia.post('/cart/destroy');
        },
        action(rowId, behavior) {
            axios.post(`/cart/${behavior}`, {rowId: rowId}).then(
                (response) => {
                    // console.log(response)
                    return response.data
                }
            ).then(
                (json) => {
                    console.log(json)
                    document.querySelector('#'+rowId).value = json.qty;
                }
            )
                .catch(
                    (err) => {
                        console.log(err);
                    }
                )
        },
    },
    mounted() {
        // console.log(this.cart)
    },

}
</script>
