<template>
    <Layout>
        Admin
    </Layout>
</template>
<script>
import Layout from '@/Components/Shared/Layout';
export default  {
    components: {
        Layout
    }

}
</script>
