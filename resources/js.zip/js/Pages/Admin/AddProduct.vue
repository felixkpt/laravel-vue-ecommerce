<template>
    <Layout>
        <!--main area-->
        <main id="main" class="main-site left-sidebar">

            <div class="container">

                <div class="wrap-breadcrumb">
                    <ul>
                        <li class="item-link"><a href="#" class="link">home</a></li>
                        <li class="item-link"><span>Digital & Electronics</span></li>
                    </ul>
                </div>
                <Notification />
                <div class="row">
                    <div class="card">
                        <div class="card-header">
                            Add Product
                        </div>
                        <div class="card-body">
                            <form @submit.prevent="handleFormSubmit">
                                <div class="form-group">
                                    <label for="item" class="form-label">Product</label>
                                    <input class="form-control" type="text" id="item" v-model="form.product">
                                </div>
                                <div class="form-group">
                                    <label for="itemSlug" class="form-label">Product Slug</label>
                                    <input class="form-control" type="text" id="itemSlug" v-model="form.product_slug">
                                </div>
                                <div class="form-group">
                                    <label for="shortD" class="form-label">Short Description</label>
                                    <textarea class="form-control" id="shortD" v-model="form.short_description">
                                    </textarea>
                                </div>
                                <div class="form-group">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control" id="description" v-model="form.description">
                                    </textarea>
                                </div>
                                <div class="form-group">
                                    <label for="regularP" class="form-label">Regular Price</label>
                                    <input class="form-control" type="text" id="regularP" v-model="form.regular_price">
                                </div>
                                <div class="form-group">
                                    <label for="saleP" class="form-label">Sale Price</label>
                                    <input class="form-control" type="text" id="saleP" v-model="form.sale_price">
                                </div>
                                <div class="form-group">
                                    <label for="SKU" class="form-label">SKU</label>
                                    <input class="form-control" type="text" id="SKU" v-model="form.SKU">
                                </div>
                                <div class="form-group">
                                    <label for="inStock" class="form-label">In Stock</label>
                                    <select class="form-select" id="inStock" v-model="form.stock_status">
                                        <option value="0">--Select--</option>
                                        <option value="instock">Yes</option>
                                        <option value="outstock">No</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="quantity" class="form-label">Quantity</label>
                                    <input class="form-control" type="number" id="quantity" v-model="form.sale_quantity">
                                </div>
                                <div class="form-group">
<!--                                    <label for="image" class="form-label">Product Image</label>-->
<!--                                    <input class="form-control" type="file" id="image" v-model="form.image">-->
                                </div>
                                <div class="form-group">
                                    <label for="category" class="form-label">Category</label>
                                    <select class="form-select" id="category_id" v-model="form.category_id">
                                        <option value="0">--Select--</option>
                                        <option v-for="item in $page.props.categories" :value="item.id">{{ item.name }}</option>
                                    </select>
                                </div>
                                <button type="submit" class="mt-3 btn btn-primary">Submit</button>
                            </form>

                        </div>
                    </div>
                </div><!--end row-->

            </div><!--end container-->

        </main>
        <!--main area-->
    </Layout>
</template>


<script>
import Layout from '@/Components/Shared/Layout';
import Notification from '@/Components/Shared/Notification';
export default  {
    components: {
        Layout,
        Notification,
    },
    data() {
        return {
            form: {
                product: null,
                product_slug: null,
                short_description: null,
                description: null,
                regular_price: null,
                sale_price: null,
                SKU: null,
                stock_status: 0,
                sale_quantity: null,
                image: null,
                category_id: 0,
            }
        }
    },
    methods: {

        handleFormSubmit() {

            this.$inertia.post('/admin/products/add', this.form);

        }
    }

}
</script>
