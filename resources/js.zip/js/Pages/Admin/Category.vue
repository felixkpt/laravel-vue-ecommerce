<template>
    <Layout>
        <!--main area-->
        <main id="main" class="main-site left-sidebar">

            <div class="container">

                <div class="wrap-breadcrumb">
                    <ul>
                        <li class="item-link"><a href="#" class="link">home</a></li>
                        <li class="item-link"><span>Digital & Electronics</span></li>
                    </ul>
                </div>
                <Notification />
                <div class="row">
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-6">
                                    <h4>All Categories</h4>
                                </div>
                                <div class="col-6 text-right">
                                    <Link href="/admin/categories/add" class="btn btn-success btn-sm">Add New</Link>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>#</th><th>Category Name</th><th>Slug</th><th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr v-for="(category, index) in $page.props.categories">
                                    <td>{{ (index + 1) }}</td><td>{{ category.name }}</td><td>{{ category.slug }}</td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button id="btnGroupDropActions" type="button" class="btn btn-light dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                                Actions
                                            </button>
                                            <ul class="dropdown-menu" aria-labelledby="btnGroupDropActions">
                                                <li>
                                                    <Link class="dropdown-item" :href="`/categories/${category.slug}`">
                                                        <span class="fa fa-eye fa-2x"></span> View
                                                    </Link>
                                                </li>
                                                <li>
                                                    <Link class="dropdown-item" :href="`/admin/categories/edit/${category.slug}`">
                                                        <span class="fa fa-edit fa-2x"></span> Edit
                                                    </Link>
                                                </li>
                                                <li>
                                                    <Link class="dropdown-item" @click.prevent="deleteCategory(category.id)">
                                                        <span class="fa fa-trash fa-2x"></span> Delete
                                                    </Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div><!--end row-->

            </div><!--end container-->

        </main>
        <!--main area-->
    </Layout>
</template>


<script>
import Layout from '@/Components/Shared/Layout';
import Notification from '@/Components/Shared/Notification';
export default  {
    components: {
        Layout,
        Notification,
    },
    data() {
        return {

        }
    },
    methods: {

        deleteCategory(id) {
            if (confirm('Are you sure you want to delete this category?')){
                this.$inertia.delete(`/admin/categories/delete/${id}`);
            }
        }

    }

}
</script>
