<template>
    <Layout>
        <!--main area-->
        <main id="main" class="main-site left-sidebar">

            <div class="container">

                <div class="wrap-breadcrumb">
                    <ul>
                        <li class="item-link"><a href="#" class="link">home</a></li>
                        <li class="item-link"><span>Digital & Electronics</span></li>
                    </ul>
                </div>
                <Notification />
                <div class="row">
                    <div class="card">
                        <div class="card-header">
                            Edit Category
                        </div>
                        <div class="card-body">
                            <form @submit.prevent="handleFormSubmit">
                                <div class="form-group">
                                    <label for="item">Category</label>
                                    <input class="form-control" type="text" id="item" v-model="form.category">
                                </div>
                                <div class="form-group">
                                    <label for="itemSlug">Category Slug</label>
                                    <input class="form-control" type="text" id="itemSlug" v-model="form.category_slug">
                                </div>
                                <button type="submit" class="mt-3 btn btn-primary">Submit</button>
                            </form>

                        </div>
                    </div>
                </div><!--end row-->

            </div><!--end container-->

        </main>
        <!--main area-->
    </Layout>
</template>


<script>
import Layout from '@/Components/Shared/Layout';
import Notification from '@/Components/Shared/Notification';
export default  {
    components: {
        Layout,
        Notification,
    },
    data() {
        return {
            form: {
                category: this.$page.props.category.name,
                category_slug: this.$page.props.category.slug,
                id: this.$page.props.category.id,
            }
        }
    },
    methods: {

        handleFormSubmit() {

            this.$inertia.patch('/admin/categories/edit', this.form);

        }
    }

}
</script>
