<template>
    <Layout>
        <!--main area-->
        <main id="main" class="main-site left-sidebar">

            <div class="container">

                <div class="wrap-breadcrumb">
                    <ul>
                        <li class="item-link"><a href="#" class="link">home</a></li>
                        <li class="item-link"><span>Digital & Electronics</span></li>
                    </ul>
                </div>
                <Notification />
                <div class="row">
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-6">
                                    <h4>All Products</h4>
                                </div>
                                <div class="col-6 text-right">
                                    <Link href="/admin/products/add" class="btn btn-success btn-sm">Add New</Link>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Img</th>
                                    <th>Name</th>
                                    <th>Stock</th>
                                    <th>Price</th>
                                    <th>Category</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr v-for="(product, index) in $page.props.products">
                                    <td>{{ (index + 1) }}</td>
                                    <td><img :src="`/public/assets/images/products/${product.image}`" sizes="30,30" alt=""></td>
                                    <td>{{ product.name }}</td><td>{{ product.stock_status }}</td>
                                    <td>{{ product.regular_price }}</td>
                                    <td>
                                    <ul class="listunstyled">
                                        <li v-for="category in product.category">
                                            {{ category.name }}
                                        </li>
                                    </ul>
                                </td>
                                    <td>{{ product.created_at }}</td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button id="btnGroupDropActions" type="button" class="btn btn-light dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                                Actions
                                            </button>
                                            <ul class="dropdown-menu" aria-labelledby="btnGroupDropActions">
                                                <li>
                                                    <Link class="dropdown-item" :href="`/product/${product.slug}`">
                                                        <span class="fa fa-eye fa-2x text-dark"></span> View
                                                    </Link>
                                                </li>
                                                <li>
                                                    <Link class="dropdown-item" :href="`/admin/products/edit/${product.slug}`">
                                                        <span class="fa fa-edit fa-2x text-info"></span> Edit
                                                    </Link>
                                                </li>
                                                <li>
                                                    <Link class="dropdown-item" @click.prevent="deleteProduct(product.id)">
                                                        <span class="fa fa-trash fa-2x text-danger"></span> Delete
                                                    </Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div><!--end row-->

            </div><!--end container-->

        </main>
        <!--main area-->
    </Layout>
</template>


<script>
import Layout from '@/Components/Shared/Layout';
import Notification from '@/Components/Shared/Notification';
export default  {
    components: {
        Layout,
        Notification,
    },
    data() {
        return {

        }
    },
    methods: {

        deleteProduct(id) {
            if (confirm('Are you sure you want to delete this product?')){
                this.$inertia.delete(`/admin/products/delete/${id}`);
            }
        }

    },
    mounted() {
        console.log(this.$page.props.products)
    }

}
</script>
