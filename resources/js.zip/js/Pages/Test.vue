<template>
    <div class="container">

        <Notification />
        <form action="/test-post" method="get">
            <input type="text" name="user">
            <input type="text" name="email">
            <input type="submit" name="submit" value="CHECK!">
        </form>
    </div>
</template>
<script>
import Layout from '@/Components/Shared/Layout';
import Notification from '@/Components/Shared/Notification';
export default  {
    components: {
        Layout,
        Notification,
    },
    data() {
        return {
            form: {
                user: null,
                submit: null
            }
        }
    },
    methods: {

        action() {

            this.$inertia.post('/admin/categories/add', this.form);

        }
    },

}
</script>
