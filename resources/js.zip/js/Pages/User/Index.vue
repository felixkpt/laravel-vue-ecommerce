<template>
    <Layout>
    User
    </Layout>
</template>
<script>
import Layout from '@/Components/Shared/Layout';
export default  {
    components: {
        Layout
    }

}
</script>
